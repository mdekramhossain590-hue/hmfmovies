"use client";
import { useEffect, useState } from "react";
type Item = { id: number; title?: string; name?: string; poster_path?: string; backdrop_path?: string; overview?: string; release_date?: string; first_air_date?: string; media_type?: string; vote_average?: number };
const img = (p?: string, size = "w342") => p ? `https://image.tmdb.org/t/p/${size}${p}` : "";
export default function Home() {
 const [items,setItems] = useState<Item[]>([]);
 const [query,setQuery] = useState("");
 const [busy,setBusy] = useState(true);
 const [selected,setSelected] = useState<Item|null>(null);
 const [details,setDetails] = useState<any>(null);
 const [kind,setKind] = useState<"movie"|"tv">("movie");
 const [error,setError] = useState("");
 async function load(url:string) {
   setBusy(true); setError("");
   try { const r=await fetch(url); const d=await r.json(); if(!r.ok) throw new Error(d.message || "Could not load movies"); setItems(d.results || []); }
   catch(e:any) { setError(e.message || "Something went wrong."); setItems([]); }
   finally { setBusy(false); }
 }
 useEffect(()=>{load("/api/tmdb/discover?type=movie&page=1");},[]);
 async function search(e?:React.FormEvent) { e?.preventDefault(); if(!query.trim()) return load(`/api/tmdb/discover?type=${kind}&page=1`); await load(`/api/tmdb/search?query=${encodeURIComponent(query)}`); }
 async function open(item:Item) {
   setSelected(item); setDetails(null);
   const type = item.media_type === "tv" || item.name ? "tv" : kind;
   try { const r=await fetch(`/api/tmdb/details?id=${item.id}&type=${type}`); const d=await r.json(); if(!r.ok) throw new Error(d.message); setDetails({...d, _type:type}); } catch(e:any) {setError(e.message || "Could not load details");}
 }
 const title=(i:Item)=>i.title || i.name || "Untitled";
 return <main>
  <header className="top"><a className="brand" href="/">HMF <span>MOVIE&apos;S</span></a><nav><button className={kind==="movie"?"active":""} onClick={()=>{setKind("movie");setQuery("");load("/api/tmdb/discover?type=movie&page=1")}}>Movies</button><button className={kind==="tv"?"active":""} onClick={()=>{setKind("tv");setQuery("");load("/api/tmdb/discover?type=tv&page=1")}}>TV Series</button></nav></header>
  <section className="hero"><p className="eyebrow">DISCOVER SOMETHING GREAT</p><h1>Movies & stories<br/><span>worth watching.</span></h1><p className="sub">Explore movie and TV details, trailers, and official viewing availability.</p>
  <form onSubmit={search}><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search movies or TV shows..." aria-label="Search movies or TV shows"/><button type="submit">Search</button></form></section>
  <section className="section"><div className="sectionhead"><div><p className="eyebrow">YOUR NEXT WATCH</p><h2>{query ? "Search results" : kind==="movie" ? "Popular movies" : "Popular TV series"}</h2></div><button className="quiet" onClick={()=>load(`/api/tmdb/discover?type=${kind}&page=1`)}>Refresh ↻</button></div>
  {error && <div className="notice">{error}{error.includes("TMDB_API_KEY") && <p>Add <code>TMDB_API_KEY</code> in Vercel → Settings → Environment Variables, then redeploy.</p>}</div>}
  {busy ? <p className="muted">Loading titles…</p> : <div className="grid">{items.map(i=><button className="movie" key={`${i.media_type||kind}-${i.id}`} onClick={()=>open(i)}><div className="poster">{img(i.poster_path)?<img src={img(i.poster_path)} alt={title(i)} loading="lazy"/>:<div className="noposter">HMF<br/>MOVIE&apos;S</div>}<span className="rating">★ {i.vote_average?.toFixed(1) || "—"}</span></div><strong>{title(i)}</strong><small>{(i.release_date||i.first_air_date||"").slice(0,4)}{i.media_type ? ` · ${i.media_type.toUpperCase()}` : ""}</small></button>)}</div>}
  </section>
  {selected && <div className="overlay" onClick={()=>{setSelected(null);setDetails(null)}}><article className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>{setSelected(null);setDetails(null)}}>✕</button>{details ? <><div className="detailhero" style={{backgroundImage:details.backdrop_path?`linear-gradient(90deg,#090b10 12%,rgba(9,11,16,.65)),url(${img(details.backdrop_path,"w1280")})`:undefined}}><p className="eyebrow">{details._type==="tv"?"TV SERIES":"MOVIE"} · {String(details.release_date||details.first_air_date||"").slice(0,4)}</p><h2>{title(details)}</h2><p>{details.overview || "No synopsis available."}</p><p className="score">★ {details.vote_average?.toFixed(1) || "—"} / 10</p></div><div className="modalbody"><h3>Trailers & official viewing options</h3>{(details.videos?.results||[]).filter((v:any)=>v.site==="YouTube" && (v.type==="Trailer"||v.type==="Teaser")).slice(0,3).map((v:any)=><a className="option" key={v.key} href={`https://www.youtube.com/watch?v=${v.key}`} target="_blank" rel="noreferrer">▶ {v.name} <span>Open YouTube ↗</span></a>)}{!(details.videos?.results||[]).some((v:any)=>v.site==="YouTube" && (v.type==="Trailer"||v.type==="Teaser"))&&<p className="muted">No trailer listed by TMDB.</p>}<p className="muted">Availability depends on your country and provider. Check official viewing options on TMDB.</p><a className="primarylink" href={`https://www.themoviedb.org/${details._type}/${details.id}/watch`} target="_blank" rel="noreferrer">Check official streaming availability ↗</a></div></>:<p className="muted pad">Loading details…</p>}</article></div>}
  <footer><b>HMF MOVIE&apos;S</b><p>Movie information powered by TMDB. This product uses the TMDB API but is not endorsed or certified by TMDB.</p><small>Use only content and video sources you are authorized to publish.</small></footer>
 </main>;
}
