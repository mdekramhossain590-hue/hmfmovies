import { NextRequest, NextResponse } from "next/server";

const TMDB_BASE = "https://api.themoviedb.org/3";
const allowed = new Set([
  "discover/movie", "discover/tv", "search/multi",
]);
function jsonError(message: string, status = 400) {
  return NextResponse.json({ status: "error", message }, { status });
}
export async function GET(req: NextRequest, ctx: { params: { path: string[] } }) {
  const key = process.env.TMDB_API_KEY;
  if (!key) return jsonError("TMDB_API_KEY is not configured in Vercel Environment Variables.", 503);
  const path = (ctx.params.path || []).join("/");
  const params = new URLSearchParams(req.nextUrl.searchParams);
  params.delete("api_key");
  let endpoint = path;
  if (path === "discover") endpoint = `discover/${params.get("type") === "tv" ? "tv" : "movie"}`;
  if (path === "details") {
    const id = params.get("id");
    const type = params.get("type") === "tv" ? "tv" : "movie";
    if (!id || !/^\d+$/.test(id)) return jsonError("A valid TMDB id is required.");
    endpoint = `${type}/${id}`;
    params.delete("id"); params.delete("type");
    params.set("append_to_response", "videos,credits,similar,recommendations,watch/providers");
  } else if (path === "season_details") {
    const id = params.get("id"), season = params.get("s") || "1";
    if (!id || !/^\d+$/.test(id) || !/^\d+$/.test(season)) return jsonError("Valid series id and season are required.");
    endpoint = `tv/${id}/season/${season}`; params.delete("id"); params.delete("s");
  } else if (path === "discover") {
    const type = params.get("type") === "tv" ? "tv" : "movie";
    endpoint = `discover/${type}`; params.delete("type");
    params.set("include_adult", "false"); params.set("sort_by", params.get("sort") || "popularity.desc");
    params.delete("sort");
    const year = params.get("year");
    if (year) { params.delete("year"); params.set(type === "tv" ? "first_air_date_year" : "primary_release_year", year); }
    const genre = params.get("genre"); if (genre) { params.delete("genre"); params.set("with_genres", genre); }
  } else if (path === "search") {
    endpoint = "search/multi";
    const query = params.get("query");
    if (!query?.trim()) return jsonError("Search query is required.");
    params.set("include_adult", "false");
  } else if (path === "watch") {
    const id = params.get("id"), type = params.get("type") === "tv" ? "tv" : "movie";
    if (!id || !/^\d+$/.test(id)) return jsonError("A valid TMDB id is required.");
    endpoint = `${type}/${id}/watch/providers`; params.delete("id"); params.delete("type");
  } else if (path === "stream_sources") {
    return NextResponse.json({ status: "info", message: "This version lists official availability only. Connect a licensed streaming provider or your own authorized video source to enable playback.", servers: [] });
  } else if (!allowed.has(path)) {
    return jsonError("Unknown API action.", 404);
  }
  params.set("api_key", key);
  const url = `${TMDB_BASE}/${endpoint}?${params.toString()}`;
  try {
    const upstream = await fetch(url, { next: { revalidate: path === "search" ? 60 : 3600 } });
    const data = await upstream.json();
    return NextResponse.json(data, { status: upstream.status, headers: { "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600" } });
  } catch {
    return jsonError("TMDB request failed. Try again later.", 502);
  }
}
