import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "HMF MOVIE'S",
  description: "Discover movies and TV series, explore details, trailers and official viewing options.",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
