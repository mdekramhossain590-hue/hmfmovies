# HMF MOVIE'S — Vercel migration starter

This is a first working migration scaffold based on the uploaded `Mega Movie Script.zip`. It is **not yet a feature-for-feature conversion** of the original Blogger XML theme.

## Included
- Next.js app suitable for Vercel deployment
- TMDB API proxy routes for discover, search, details, season details, and official watch-provider availability
- TMDB API key kept server-side in `TMDB_API_KEY`
- Responsive movie/TV discovery UI with details and official YouTube trailers
- Original project files preserved in `original-project/` for reference

## Deploy
1. Push this folder's contents to your GitHub repository (the contents of this folder, not the ZIP file itself).
2. In Vercel, import the repository.
3. In Vercel → Project → Settings → Environment Variables, add `TMDB_API_KEY` with your own TMDB API key. Do not commit the real key to GitHub.
4. Deploy / redeploy.

## API paths
- `/api/tmdb/discover?type=movie&page=1`
- `/api/tmdb/discover?type=tv&page=1`
- `/api/tmdb/search?query=batman`
- `/api/tmdb/details?id=603&type=movie`
- `/api/tmdb/season_details?id=1399&s=1`
- `/api/tmdb/watch?id=603&type=movie`

## Important migration notes
- The old `DualEngineAPI.php` contains third-party streaming embed URLs. This scaffold intentionally does not reproduce unauthorized streaming link resolution. The details screen links to TMDB's official availability page; connect only a licensed provider or a video source you have permission to use.
- The old `cleaner.php` deletes local filesystem cache. Vercel Functions use ephemeral filesystems, so this should not be copied as-is. The current API uses Vercel/CDN caching for eligible TMDB responses. A persistent cache or scheduled job can be added if needed.
- The Blogger XML theme is retained under `original-project/` but has not been automatically converted into React. Blogger-specific tags and data bindings cannot simply be deployed as a normal Vercel page; the UI in `app/page.tsx` is a starter replacement, and full visual parity requires further conversion/testing.
- `manifest.json` and `sw.js` are retained and a minimal public version is included. Full PWA icon assets still need to be supplied.
- TMDB attribution is included in the UI. Review TMDB's current terms and branding requirements before public launch.
